/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.Map;

/**
 * The type Sin.
 */
public class Sin extends UnaryExpression implements Expression {
    /**
     * Instantiates a new Sin.
     *
     * @param one the one
     */
// constructors

    /**
     * Instantiates a new Sin.
     *
     * @param one the one
     */
    public Sin(String one) {
        super(new Var(one));
    }

    /**
     * Instantiates a new Sin.
     *
     * @param one the one
     */
    public Sin(double one) {
        super(new Num(one));
    }

    /**
     * Instantiates a new Sin.
     *
     * @param one the one
     */
    public Sin(Expression one) {
        super(one);
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        try {
            double num = this.getExp().evaluate(assignment);
            double rad = Math.toRadians(num);
            if (Math.abs(Math.sin(rad)) < 0.00001) {
                return 0;
            } else {
                return Math.sin(rad);
            }
        } catch (Exception e) {
            throw e;
        }
    }
    /**
     * toString.
     *
     * @return the string
     */
    public String toString() {
        String s;
        s = "sin" + "(" + this.getExp().toString() + ")";
        return s;
    }
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public Expression assign(String var, Expression expression) {
        Sin m = new Sin(this.getExp().assign(var, expression));
        return m;
    }
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public Expression differentiate(String var) {
        return new Mult(super.getExp().differentiate(var), new Cos(super.getExp()));
    }
    /**
     * Simplify expression.
     *
     * @return the expression
     * @throws Exception the exception
     */
    public Expression simplify() throws Exception {
        Expression e1 = super.getExp().simplify();
        if (this.getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }
        return new Sin(e1);
    }
}
