/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The type Base expression.
 */
abstract class BaseExpression implements Expression {
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public abstract double evaluate(Map<String, Double> assignment) throws
            Exception;
    /**
     * Evaluate double.
     *
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate() throws Exception {
        HashMap<String, Double> map = new HashMap<String, Double>();
        map.put("e", Math.E);
        map.put("PI", Math.PI);
        return evaluate(map);
    }
    /**
     * Gets variables.
     *
     * @return the variables
     */
    public abstract List<String> getVariables();
    /**
     * toString.
     *
     * @return the string
     */
    public abstract String toString();
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public abstract Expression assign(String var, Expression expression);
}
