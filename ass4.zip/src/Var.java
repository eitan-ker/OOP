/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The type Var.
 */
public class Var implements Expression {
    private String variable;

    /**
     * Instantiates a new Var.
     *
     * @param var the var
     */
    public Var(String var) {
        this.variable = var;
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        if (assignment.containsKey(this.variable)) {
            return assignment.get(this.variable);
        }
        throw new Exception("Key was not found");
    }

    /**
     * Evaluate double.
     *
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate() throws Exception {
        throw new Exception("Key was not found");
    }
    /**
     * Gets variables.
     *
     * @return the variables
     */
    public List<String> getVariables() {
        List<String> list = new ArrayList<String>();
        list.add(this.variable);
        return list;
    }
    /**
     * toString.
     *
     * @return the string
     */
    public String toString() {
        return this.variable;
    }
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public Expression assign(String var, Expression expression) {
        if (this.variable == var) {
            return expression;
        } else {
            return this;
        }
    }
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public Expression differentiate(String var) {
        if (this.variable == var) {
            return new Num(1);
        } else {
            return new Num(0);
        }
    }
    /**
     * Simplify expression.
     *
     * @return the expression
     */
    public Expression simplify() {
        return this;
    }
}
