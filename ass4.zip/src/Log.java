/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.Map;

/**
 * The type Log.
 */
public class Log extends BinaryExpression implements Expression {
    /**
     * Instantiates a new Log.
     *
     * @param one the one
     * @param two the two
     */
// constructors
    public Log(Expression one, Expression two) {
        super(one, two);
    }

    /**
     * Instantiates a new Log.
     *
     * @param one the one
     * @param two the two
     */
    public Log(Expression one, String two) {
        super(one, new Var(two));
    }

    /**
     * Instantiates a new Log.
     *
     * @param one the one
     * @param two the two
     */
    public Log(Expression one, double two) {
        super(one, new Num(two));
    }

    /**
     * Instantiates a new Log.
     *
     * @param one the one
     * @param two the two
     */
    public Log(String one, String two) {
        super(new Var(one), new Var(two));
    }

    /**
     * Instantiates a new Log.
     *
     * @param one the one
     * @param two the two
     */
    public Log(String one, Expression two) {
        super(new Var(one), two);
    }

    /**
     * Instantiates a new Log.
     *
     * @param one the one
     * @param two the two
     */
    public Log(String one, double two) {
        super(new Var(one), new Num(two));
    }

    /**
     * Instantiates a new Log.
     *
     * @param one the one
     * @param two the two
     */
    public Log(double one, double two) {
        super(new Num(one), new Num(two));
    }

    /**
     * Instantiates a new Log.
     *
     * @param one the one
     * @param two the two
     */
    public Log(double one, Expression two) {
        super(new Num(one), two);
    }

    /**
     * Instantiates a new Log.
     *
     * @param one the one
     * @param two the two
     */
    public Log(double one, String two) {
        super(new Num(one), new Var(two));
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        return (Math.log10(this.getSecond().evaluate(assignment))
                / Math.log10(this.getFirst().evaluate(assignment)));
    }
    /**
     * toString.
     *
     * @return the string
     */
    public String toString() {
        String s;
        s = "log" + "(" + this.getFirst().toString() + ", " + this.getSecond().
                toString() + ")";
        return s;
    }
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public Expression assign(String var, Expression expression) {
        Log p = new Log(this.getFirst().assign(var, expression), this.getSecond().assign(var, expression));
        return p;
    }
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public Expression differentiate(String var) {
        return new Mult(super.getSecond().differentiate(var), new Div(1,
                new Mult(super.getSecond(), new Log("e", super.getFirst()))));
    }
    /**
     * Simplify expression.
     *
     * @return the expression
     * @throws Exception the exception
     */
    public Expression simplify() throws Exception {
        Expression e1 = super.getFirst().simplify();
        Expression e2 = super.getSecond().simplify();
        if (this.getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }
        if (e1.toString().equals(e2.toString())) {
            return new Num(1);
        }
        return new Log(e1, e2);
    }
}
