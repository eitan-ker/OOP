/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The type Binary expression.
 */
abstract class BinaryExpression extends BaseExpression {

    private Expression first;
    private Expression second;

    /**
     * Instantiates a new Binary expression.
     *
     * @param one the one
     * @param two the two
     */
// constructor
    BinaryExpression(Expression one, Expression two) {
        this.first = one;
        this.second = two;
    }


    /**
     * Gets first.
     *
     * @return the first
     */
// getters
    public Expression getFirst() {
        return this.first;
    }

    /**
     * Gets second.
     *
     * @return the second
     */
    public Expression getSecond() {
        return this.second;
    }

    /**
     * Sets first.
     *
     * @param exp1 the exp 1
     */
// setters
    public void setFirst(Expression exp1) {
        this.first = exp1;
    }

    /**
     * Sets second.
     *
     * @param exp2 the exp 2
     */
    public void setSecond(Expression exp2) {
        this.second = exp2;
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public abstract double evaluate(Map<String, Double> assignment) throws
            Exception;
    /**
     * Gets variables.
     *
     * @return the variables
     */
    public List<String> getVariables() {
        List<String> list1 = this.first.getVariables();
        List<String> list2 = this.second.getVariables();
        List<String> newList = new ArrayList<String>();
        if (list1 != null) {
            for (int i = 0; i < list1.size(); i++) {
                newList.add(list1.get(i));
            }
        }
        if (list2 != null) {
            for (int i = 0; i < list2.size(); i++) {
                newList.add(list2.get(i));
            }
        }
        return newList;
    }
    /**
     * toString.
     *
     * @return the string
     */
    public abstract String toString();
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public abstract Expression assign(String var, Expression expression);
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public abstract Expression differentiate(String var);
}
