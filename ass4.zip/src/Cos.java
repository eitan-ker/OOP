/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.Map;

/**
 * The type Cos.
 */
public class Cos extends UnaryExpression implements Expression {
    /**
     * Instantiates a new Cos.
     *
     * @param one the one
     */
// constructors
    public Cos(Expression one) {
        super(one);
    }

    /**
     * Instantiates a new Cos.
     *
     * @param one the one
     */
    public Cos(String one) {
        super(new Var(one));
    }

    /**
     * Instantiates a new Cos.
     *
     * @param one the one
     */
    public Cos(double one) {
        super(new Num(one));
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        try {
            double num = this.getExp().evaluate(assignment);
            double rad = Math.toRadians(num);
            if (Math.abs(Math.cos(rad)) < 0.00001) {
                return 0;
            } else {
                return Math.cos(rad);
            }
        } catch (Exception e) {
            throw e;
        }
    }
    /**
     * toString.
     *
     * @return the string
     */
    public String toString() {
        String s;
        s = "Cos" + "(" + this.getExp().toString() + ")";
        return s;
    }
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public Expression assign(String var, Expression expression) {
        Cos m = new Cos(this.getExp().assign(var, expression));
        return m;
    }
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public Expression differentiate(String var) {
        return new Mult(super.getExp().differentiate(var), new Neg(new Sin(
                super.getExp())));
    }
    /**
     * Simplify expression.
     *
     * @return the expression
     * @throws Exception the exception
     */
    public Expression simplify() throws Exception {
        Expression e1 = super.getExp().simplify();
        if (this.getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }

        return new Cos(e1);
    }
}
