/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.Map;

/**
 * The type Pow.
 */
public class Pow extends BinaryExpression implements Expression {

    /**
     * Instantiates a new Pow.
     *
     * @param one the one
     * @param two the two
     */
// constructors
    public Pow(Expression one, Expression two) {
        super(one, two);
    }

    /**
     * Instantiates a new Pow.
     *
     * @param one the one
     * @param two the two
     */
    public Pow(Expression one, String two) {
        super(one, new Var(two));
    }

    /**
     * Instantiates a new Pow.
     *
     * @param one the one
     * @param two the two
     */
    public Pow(Expression one, double two) {
        super(one, new Num(two));
    }

    /**
     * Instantiates a new Pow.
     *
     * @param one the one
     * @param two the two
     */
    public Pow(String one, String two) {
        super(new Var(one), new Var(two));
    }

    /**
     * Instantiates a new Pow.
     *
     * @param one the one
     * @param two the two
     */
    public Pow(String one, Expression two) {
        super(new Var(one), two);
    }

    /**
     * Instantiates a new Pow.
     *
     * @param one the one
     * @param two the two
     */
    public Pow(String one, double two) {
        super(new Var(one), new Num(two));
    }

    /**
     * Instantiates a new Pow.
     *
     * @param one the one
     * @param two the two
     */
    public Pow(double one, double two) {
        super(new Num(one), new Num(two));
    }

    /**
     * Instantiates a new Pow.
     *
     * @param one the one
     * @param two the two
     */
    public Pow(double one, Expression two) {
        super(new Num(one), two);
    }

    /**
     * Instantiates a new Pow.
     *
     * @param one the one
     * @param two the two
     */
    public Pow(double one, String two) {
        super(new Num(one), new Var(two));
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        return Math.pow(this.getFirst().evaluate(assignment), this.getSecond().evaluate(assignment));
    }
    /**
     * toString.
     *
     * @return the string
     */
    public String toString() {
        String s;
        s = "(" + this.getFirst().toString() + " ^ " + this.getSecond().toString() + ")";
        return s;
    }
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public Expression assign(String var, Expression expression) {
        Pow p = new Pow(this.getFirst().assign(var, expression), this.getSecond().assign(var, expression));
        return p;
    }
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public Expression differentiate(String var) {
        return new Mult(new Pow(super.getFirst(), super.getSecond()),
                new Plus(new Mult(super.getFirst().differentiate(var),
                        new Div(super.getSecond(), super.getFirst())),
                        new Mult(super.getSecond().differentiate(var),
                                new Log("e", super.getFirst()))));
    }
    /**
     * Simplify expression.
     *
     * @return the expression
     * @throws Exception the exception
     */
    public Expression simplify() throws Exception {
        Expression e1 = super.getFirst().simplify();
        Expression e2 = super.getSecond().simplify();
        if (this.getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }
        if (e2.toString().equals("0.0")) {
            return new Num(1);
        }
        if (e2.toString().equals("1.0")) {
            return e1;
        }
        if (e1.toString().equals("1.0")) {
            return e1;
        }
        return new Pow(e1, e2);
    }
}
