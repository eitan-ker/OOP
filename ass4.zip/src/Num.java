/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.List;
import java.util.Map;

/**
 * The type Num.
 */
public class Num implements Expression {
    private double number;

    /**
     * Instantiates a new Num.
     *
     * @param num the num
     */
    public Num(double num) {
        this.number = num;
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        return this.number;
    }
    /**
     * Evaluate double.
     *
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate() throws Exception {
        return this.number;
    }
    /**
     * Gets variables.
     *
     * @return the variables
     */
    public List<String> getVariables() {
        return null;
    }
    /**
     * toString.
     *
     * @return the string
     */
    public String toString() {
        return Double.toString(number);
    }
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public Expression assign(String var, Expression expression) {
        return this;
    }
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public Expression differentiate(String var) {
        return new Num(0);
    }
    /**
     * Simplify expression.
     *
     * @return the expression
     */
    public Expression simplify() {
        return this;
    }
}
