/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.Map;

/**
 * The type Neg.
 */
public class Neg extends UnaryExpression implements Expression {

    /**
     * Instantiates a new Neg.
     *
     * @param one the one
     */
// constructors
    public Neg(Expression one) {
        super(one);
    }

    /**
     * Instantiates a new Neg.
     *
     * @param one the one
     */
    public Neg(String one) {
        super(new Var(one));
    }

    /**
     * Instantiates a new Neg.
     *
     * @param one the one
     */
    public Neg(double one) {
        super(new Num(one));
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate(Map<String, Double> assignment) throws
            Exception {
        try {
            return this.getExp().evaluate(assignment) * (-1);
        } catch (Exception e) {
            throw e;
        }
    }
    /**
     * toString.
     *
     * @return the string
     */
    public String toString() {
        String s;
        s = "(" + "-" + this.getExp().toString() + ")";
        return s;
    }
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public Expression assign(String var, Expression expression) {
        Neg m = new Neg(this.getExp().assign(var, expression));
        return m;
    }
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public Expression differentiate(String var) {
        return new Neg(super.getExp().differentiate(var));
    }
    /**
     * Simplify expression.
     *
     * @return the expression
     * @throws Exception the exception
     */
    public Expression simplify() throws Exception {
        Expression e1 = super.getExp().simplify();
        if (this.getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }
        return new Neg(e1);
    }
}
