/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The type Unary expression.
 */
abstract class UnaryExpression extends BaseExpression {

    private Expression exp;

    /**
     * Instantiates a new Unary expression.
     *
     * @param one the one
     */
// constructor
    UnaryExpression(Expression one) {
        this.exp = one;
    }

    /**
     * Gets exp.
     *
     * @return the exp
     */
// getters
    public Expression getExp() {
        return this.exp;
    }

    /**
     * Sets exp.
     *
     * @param exp1 the exp 1
     */
// setter
    public void setExp(Expression exp1) {
        this.exp = exp1;
    }

    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public abstract double evaluate(Map<String, Double> assignment) throws Exception;
    /**
     * Gets variables.
     *
     * @return the variables
     */
    public List<String> getVariables() {
        List<String> list = this.exp.getVariables();
        List<String> newList = new ArrayList<String>();
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                newList.add(list.get(i));
            }
        }
        return newList;
    }
    /**
     * toString.
     *
     * @return the string
     */
    public abstract String toString();
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public abstract Expression assign(String var, Expression expression);
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public abstract Expression differentiate(String var);
}
