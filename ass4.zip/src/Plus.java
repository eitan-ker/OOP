/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.Map;

/**
 * The type Plus.
 */
public class Plus extends BinaryExpression implements Expression {

    /**
     * Instantiates a new Plus.
     *
     * @param one the one
     * @param two the two
     */
// constructors
    public Plus(Expression one, Expression two) {
        super(one, two);
    }

    /**
     * Instantiates a new Plus.
     *
     * @param one the one
     * @param two the two
     */
    public Plus(Expression one, String two) {
        super(one, new Var(two));
    }

    /**
     * Instantiates a new Plus.
     *
     * @param one the one
     * @param two the two
     */
    public Plus(Expression one, double two) {
        super(one, new Num(two));
    }

    /**
     * Instantiates a new Plus.
     *
     * @param one the one
     * @param two the two
     */
    public Plus(String one, String two) {
        super(new Var(one), new Var(two));
    }

    /**
     * Instantiates a new Plus.
     *
     * @param one the one
     * @param two the two
     */
    public Plus(String one, Expression two) {
        super(new Var(one), two);
    }

    /**
     * Instantiates a new Plus.
     *
     * @param one the one
     * @param two the two
     */
    public Plus(String one, double two) {
        super(new Var(one), new Num(two));
    }

    /**
     * Instantiates a new Plus.
     *
     * @param one the one
     * @param two the two
     */
    public Plus(double one, double two) {
        super(new Num(one), new Num(two));
    }

    /**
     * Instantiates a new Plus.
     *
     * @param one the one
     * @param two the two
     */
    public Plus(double one, Expression two) {
        super(new Num(one), two);
    }

    /**
     * Instantiates a new Plus.
     *
     * @param one the one
     * @param two the two
     */
    public Plus(double one, String two) {
        super(new Num(one), new Var(two));
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        try {
            return this.getFirst().evaluate(assignment) + this.getSecond().evaluate(assignment);
        } catch (Exception e) {
            throw e;
        }
    }
    /**
     * toString.
     *
     * @return the string
     */
    public String toString() {
        String s;
        s = "(" + this.getFirst().toString() + " + " + this.getSecond().toString() + ")";
        return s;
    }
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public Expression assign(String var, Expression expression) {
        Plus p = new Plus(this.getFirst().assign(var, expression), this.getSecond().assign(var, expression));
        return p;
    }
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public Expression differentiate(String var) {
        return new Plus(super.getFirst().differentiate(var), super.getSecond().differentiate(var));
    }
    /**
     * Simplify expression.
     *
     * @return the expression
     * @throws Exception the exception
     */
    public Expression simplify() throws Exception {
        Expression e1 = super.getFirst().simplify();
        Expression e2 = super.getSecond().simplify();
        if (this.getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }
        if (e1.toString().equals(new Neg(e2.toString()))) {
            return new Num(0);
        }
        if (e2.toString().equals("0.0")) {
            return e1;
        }
        if (e1.toString().equals("0.0")) {
            return e2;
        }
        if (e1.toString().equals(e2.toString())) {
            return new Mult(2, e1);
        }
        return new Plus(e1, e2);
    }
}
