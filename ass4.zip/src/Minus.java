/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */

import java.util.Map;

/**
 * The type Minus.
 */
public class Minus extends BinaryExpression implements Expression {

    /**
     * Instantiates a new Minus.
     *
     * @param one the one
     * @param two the two
     */
// constructors
    public Minus(Expression one, Expression two) {
        super(one, two);
    }

    /**
     * Instantiates a new Minus.
     *
     * @param one the one
     * @param two the two
     */
    public Minus(Expression one, String two) {
        super(one, new Var(two));
    }

    /**
     * Instantiates a new Minus.
     *
     * @param one the one
     * @param two the two
     */
    public Minus(Expression one, double two) {
        super(one, new Num(two));
    }

    /**
     * Instantiates a new Minus.
     *
     * @param one the one
     * @param two the two
     */
    public Minus(String one, String two) {
        super(new Var(one), new Var(two));
    }

    /**
     * Instantiates a new Minus.
     *
     * @param one the one
     * @param two the two
     */
    public Minus(String one, Expression two) {
        super(new Var(one), two);
    }

    /**
     * Instantiates a new Minus.
     *
     * @param one the one
     * @param two the two
     */
    public Minus(String one, double two) {
        super(new Var(one), new Num(two));
    }

    /**
     * Instantiates a new Minus.
     *
     * @param one the one
     * @param two the two
     */
    public Minus(double one, double two) {
        super(new Num(one), new Num(two));
    }

    /**
     * Instantiates a new Minus.
     *
     * @param one the one
     * @param two the two
     */
    public Minus(double one, Expression two) {
        super(new Num(one), two);
    }

    /**
     * Instantiates a new Minus.
     *
     * @param one the one
     * @param two the two
     */
    public Minus(double one, String two) {
        super(new Num(one), new Var(two));
    }
    /**
     * Evaluate double.
     *
     * @param assignment the assignment
     * @return the double
     * @throws Exception the exception
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        try {
            return this.getFirst().evaluate(assignment) - this.getSecond().evaluate(assignment);
        } catch (Exception e) {
            throw e;
        }
    }
    /**
     * toString.
     *
     * @return the string
     */
    public String toString() {
        String s;
        s = "(" + this.getFirst().toString() + " - " + this.getSecond().toString() + ")";
        return s;
    }
    /**
     * Assign expression.
     *
     * @param var        the var
     * @param expression the expression
     * @return the expression
     */
    public Expression assign(String var, Expression expression) {
        Minus m = new Minus(this.getFirst().assign(var, expression), this.getSecond().assign(var, expression));
        return m;
    }
    /**
     * Differentiate expression.
     *
     * @param var the var
     * @return the expression
     */
    public Expression differentiate(String var) {
        return new Minus(super.getFirst().differentiate(var), super.getSecond().differentiate(var));
    }
    /**
     * Simplify expression.
     *
     * @return the expression
     * @throws Exception the exception
     */
    public Expression simplify() throws Exception {
        Expression e1 = super.getFirst().simplify();
        Expression e2 = super.getSecond().simplify();
        if (this.getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }
        if (e1.toString().equals(e2.toString())) {
            return new Num(0);
        }
        if (e2.toString().equals("0.0")) {
            return e1;
        }
        if (e1.toString().equals("0.0")) {
            return new Neg(e2);
        }
        return new Minus(e1, e2);
    }
}