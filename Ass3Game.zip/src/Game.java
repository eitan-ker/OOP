
import java.awt.Color;

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 *
 * The type Game.
 */
public class Game {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;

    /**
     * Instantiates a new Game.
     */
    public Game() {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.gui = new GUI("run", 800, 800);
    }

    /**
     * Add collidable.
     *
     * @param c the c
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * Add sprite.
     *
     * @param s the s
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * Initialize.
     */
// Initialize a new game: create the Blocks and Ball (and Paddle)
    // and add them to the game.
    public void initialize() {

        // ball initialize
        Ball ball1 = new Ball(50, 50, 5, java.awt.Color.white);
        Velocity v1 = Velocity.fromAngleAndSpeed(300, 8);
        ball1.setVelocity(v1);
        ball1.setEnvironment(this.environment);
        ball1.addToGame(this);

        Ball ball2 = new Ball(50, 50, 5, java.awt.Color.white);
        Velocity v2 = Velocity.fromAngleAndSpeed(250, 8);
        ball2.setVelocity(v2);
        ball2.setEnvironment(this.environment);
        ball2.addToGame(this);

        // walls initialize
        Point w1 = new Point(0, 0);
        Rectangle rw1 = new Rectangle(w1, 800, 20, java.awt.Color.gray);
        Block wall1 = new Block(rw1, 0);
        wall1.addToGame(this);

        Point w2 = new Point(0, 0);
        Rectangle rw2 = new Rectangle(w2, 20, 800, java.awt.Color.gray);
        Block wall2 = new Block(rw2, 0);
        wall2.addToGame(this);

        Point w3 = new Point(780, 0);
        Rectangle rw3 = new Rectangle(w3, 20, 800, java.awt.Color.gray);
        Block wall3 = new Block(rw3, 0);
        wall3.addToGame(this);

        Point w4 = new Point(0, 780);
        Rectangle rw4 = new Rectangle(w4, 800, 20, java.awt.Color.gray);
        Block wall4 = new Block(rw4, 0);
        wall4.addToGame(this);

        // paddle initialize
        biuoop.KeyboardSensor keyboard = gui.getKeyboardSensor();
        Point uperLeftPaddle = new Point(250, 770);
        Rectangle rect = new Rectangle(uperLeftPaddle, 100, 10,
                java.awt.Color.yellow);
        Paddle paddle = new Paddle(keyboard, rect);
        int maxXBorder = (int) rw3.getLowerLine().start().getX();
        int minXBorder = (int) rw2.getRightLine().start().getX();
        int maxYBorder = (int) rw1.getLowerLine().start().getY();
        int minYborder = (int) rw4.getUpperLine().start().getY();
        paddle.setBorders(minXBorder, maxXBorder);
        paddle.addToGame(this);

        // blocs initialize
        // run on lines
        for (int i = 0; i < 6; i++) {
            // run on columns
            int counter = 1;
            for (int j = 12 - i; j > 0; j--) {
                // setting point
                Point p = new Point(maxXBorder - (counter * 50), 100
                        + (25 * i));
                if (i == 0) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            java.awt.Color.gray);
                    Block b = new Block(rectangle, 2);
                    b.addToGame(this);
                } else if (i == 1) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            java.awt.Color.red);
                    Block b = new Block(rectangle, 1);
                    b.addToGame(this);
                } else if (i == 2) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            java.awt.Color.yellow);
                    Block b = new Block(rectangle, 1);
                    b.addToGame(this);
                } else if (i == 3) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            java.awt.Color.blue);
                    Block b = new Block(rectangle, 1);
                    b.addToGame(this);
                } else if (i == 4) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            java.awt.Color.pink);
                    Block b = new Block(rectangle, 1);
                    b.addToGame(this);
                } else if (i == 5) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            java.awt.Color.green);
                    Block b = new Block(rectangle, 1);
                    b.addToGame(this);
                }
                counter++;
            }
        }
    }

    /**
     * Run.
     */
// Run the game -- start the animation loop.
    public void run() {
        Sleeper sleeper = new Sleeper();
        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = gui.getDrawSurface();
            // fill board
            d.setColor(Color.blue);
            d.fillRectangle(0, 0, 800, 800);
            this.sprites.drawAllOn(d);
            gui.show(d);
            this.sprites.notifyAllTimePassed();

            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
}
