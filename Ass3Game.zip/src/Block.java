
import java.awt.Color;

import biuoop.DrawSurface;

/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 *
 * The type Block.
 */
public class Block implements Collidable, Sprite {
    private Rectangle rect;
    private int hp;

    /**
     * Instantiates a new Block.
     *
     * @param rect the rect
     * @param hp   the hp
     */
    public Block(Rectangle rect, int hp) {
        this.rect = rect;
        this.hp = hp;
    }

    /**
     * Sets hp.
     */
    public void setHp() {
        if (this.hp == 0) {
            this.hp = 0;
        } else {
            this.hp = this.hp - 1;
        }
    }

    /**
     * Gets color.
     *
     * @return the color
     */
    public java.awt.Color getColor() {
        return this.rect.getColor();
    }

    /**
     * Draw figures.
     *
     * @param d the surface
     */
    public void drawOn(DrawSurface d) {
        // fill rectangle;
        d.setColor(getColor());
        Point point = this.rect.getUpperLeft();
        double width = this.rect.getWidth();
        double height = this.rect.getHeight();
        d.fillRectangle((int) point.getX(), (int) point.getY(), (int) width,
                (int) height);
        d.setColor(Color.black);
        // draw upper line
        d.drawLine((int) this.rect.getUpperLeft().getX(), (int) this.rect.
                getUpperLeft().getY(), (int) (this.rect.getUpperLeft().getX()
                + this.rect.getWidth()), (int) this.rect.getUpperLeft().getY());
        d.drawLine((int) this.rect.getUpperLeft().getX(), (int) this.rect.
                        getUpperLeft().getY(), (int) (this.rect.getUpperLeft().getX()),
                (int) (this.rect.getUpperLeft().getY()
                        + this.rect.getHeight()));
        d.drawLine((int) this.rect.getUpperLeft().getX(), (int) (this.rect.
                        getUpperLeft().getY() + this.rect.getHeight()), (int) (this.
                        rect.getUpperLeft().getX() + this.rect.getWidth()),
                (int) (this.rect.getUpperLeft().getY()
                        + this.rect.getHeight()));
        d.drawLine((int) (this.rect.getUpperLeft().getX()
                + this.rect.getWidth()), (int) (this.rect.getUpperLeft().
                getY()), (int) (this.rect.getUpperLeft().getX() + this.
                rect.getWidth()), (int) (this.rect.
                getUpperLeft().getY() + this.rect.
                getHeight()));

        int textX = (int) (this.rect.getUpperLeft().getX()
                + (this.rect.getWidth() / 2));
        int textY = (int) (this.rect.getUpperLeft().getY()
                + (this.rect.getHeight()) / 2);
        d.setColor(Color.white);
        if (this.hp < 0) {
            return;
        }
        if (this.hp == 0) {
            d.drawText(textX, textY, "X", 15);
        } else {
            d.drawText(textX, textY, String.valueOf(this.hp), 15);
        }
    }
    /**
     * Time passed.
     */
    public void timePassed() {
    }
    /**
     *
     * @return the  rectangle
     */
// Return t
    public Rectangle getCollisionRectangle() {
        return this.rect;
    }
    /**
     * Hit velocity.
     *
     * @param collisionPoint  the collision point
     * @param currentVelocity the current velocity
     * @return the velocity after hit
     */
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {

// ** maybe will be problems cause i didn't check moving directions of the ball **

        double dx = currentVelocity.getDx();
        double x = collisionPoint.getX();
        double dy = currentVelocity.getDy();
        double y = collisionPoint.getY();
        double wide = this.rect.getWidth();
        double height = this.rect.getHeight();
        double upperLeftY = this.rect.getUpperLeft().getY();
        double upperLeftX = this.rect.getUpperLeft().getX();

        if (Math.abs(y - upperLeftY) < 0.01 || Math.abs(y - upperLeftY
                - height) < 0.01) {
            dy = -dy;
            this.setHp();
        }
        if (Math.abs(x - upperLeftX) < 0.01 || Math.abs(x - upperLeftX
                - wide) < 0.01) {
            dx = -dx;
            this.setHp();
        }
        Velocity newV = new Velocity(dx, dy);
        return newV;
    }

    /**
     * Add to game.
     *
     * @param g the g
     */
    public void addToGame(Game g) {
        g.addCollidable(this);
        g.addSprite(this);
    }
}
