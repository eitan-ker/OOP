/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 *
 * The type Ass 3 game.
 */
public class Ass3Game {
    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
