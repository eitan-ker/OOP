import java.util.Random;

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;


/**
 * Eitan Kerzhner
 *
 * The type Multiple frames bouncing balls animation.
 */
public class MultipleFramesBouncingBallsAnimation {
    /**
     * The Widestart first board.
     */
    static final int WIDESTART1 = 50;
    /**
     * The Highstart first board.
     */
    static final int HIGHSTART1 = 50;
    /**
     * The Wideend first board.
     */
    static final int WIDEEND1 = 500;
    /**
     * The Highend first board.
     */
    static final int HIGHEND1 = 500;
    /**
     * The Widestart second board.
     */
    static final int WIDESTART2 = 450;
    /**
     * The Highstart second board.
     */
    static final int HIGHSTART2 = 450;
    /**
     * The Wideend second board.
     */
    static final int WIDEEND2 = 600;
    /**
     * The Highend second board.
     */
    static final int HIGHEND2 = 600;

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        Random rand = new Random();
        int numberOfBalls = args.length;
        GUI gui = new GUI("title", 600, 600);
        Ball[] ballsArrays = new Ball[numberOfBalls];
        Sleeper sleeper = new Sleeper();
        for (int i = 0; i < numberOfBalls; i++) {
            if (i < (numberOfBalls / 2)) {
                // making first half if the balls
                int r = Integer.parseInt(args[i]);
                int x = rand.nextInt(450) + 50;
                int y = rand.nextInt(450) + 50;
                ballsArrays[i] = new Ball(x, y, r, java.awt.Color.red);
                ballsArrays[i].setBorders(WIDESTART1, WIDEEND1, HIGHSTART1,
                        HIGHEND1);
                Velocity v = Velocity.fromAngleAndSpeed(rand.nextInt(360) + 1,
                        100 / r); // check if needs to be modified. ****************
                ballsArrays[i].setVelocity(v);
            } else {
                // making the second half of the balls
                int r = Integer.parseInt(args[i]);
                int x = rand.nextInt(150) + 450;
                int y = rand.nextInt(150) + 450;
                ballsArrays[i] = new Ball(x, y, r, java.awt.Color.blue);
                ballsArrays[i].setBorders(WIDESTART2, WIDEEND2, HIGHSTART2,
                        HIGHEND2);
                Velocity v = Velocity.fromAngleAndSpeed(rand.nextInt(360) + 1,
                        100 / r); // check if needs to be modified. ****************
                ballsArrays[i].setVelocity(v);
            }
        }
        while (true) {
            // making all the balls move
            for (int i = 0; i < numberOfBalls; i++) {
                ballsArrays[i].moveOneStep();
            }
            DrawSurface d = gui.getDrawSurface();
            d.setColor(java.awt.Color.gray);
            d.fillRectangle(50, 50, 450, 450);
            d.setColor(java.awt.Color.yellow);
            d.fillRectangle(WIDESTART2, HIGHSTART2, 150, 150);
            for (int i = 0; i < numberOfBalls; i++) {
                ballsArrays[i].drawOn(d);
            }
            gui.show(d);
            sleeper.sleepFor(50);  // wait for 50 milliseconds.
        }
    }
}
