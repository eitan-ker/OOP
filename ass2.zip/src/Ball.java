import biuoop.DrawSurface;

/**
 * Eitan Kerzhner
 *
 * The type Ball.
 */
public class Ball {

    private Point center;
    private int r;
    private Velocity v;
    /**
     * The Color.
     */
    private java.awt.Color color;

    private int xLowBorder;
    private int xHighBorder;
    private int yLowBorder;
    private int yHighBorder;

    /**
     * Instantiates a new Ball.
     *
     * @param center the center
     * @param r      the r
     * @param color  the color
     */
// constructor
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
    }

    /**
     * Instantiates a new Ball.
     *
     * @param x     the x
     * @param y     the y
     * @param r     the r
     * @param color the color
     */
//constructor
    public Ball(int x, int y, int r, java.awt.Color color) {
        this.center = new Point(x, y);
        this.r = r;
        this.color = color;
    }

    /**
     * Sets borders.
     *
     * @param lowX  the low x
     * @param highX the high x
     * @param lowY  the low y
     * @param highY the high y
     */
    public void setBorders(int lowX, int highX, int lowY, int highY) {
        this.xLowBorder = lowX;
        this.xHighBorder = highX;
        this.yLowBorder = lowY;
        this.yHighBorder = highY;
    }

    /**
     * Gets low.
     *
     * @return the low
     */
    public int getxLow() {
        return this.xLowBorder;
    }

    /**
     * Gets high.
     *
     * @return the high
     */
    public int getxHigh() {
        return this.xHighBorder;
    }

    /**
     * Gets low.
     *
     * @return the low
     */
    public int getyLow() {
        return this.yLowBorder;
    }

    /**
     * Gets high.
     *
     * @return the high
     */
    public int getyHigh() {
        return this.yHighBorder;
    }

    /**
     * Gets x.
     *
     * @return the x
     */
    public int getX() {
        return (int) this.center.getX();
    }

    /**
     * Gets y.
     *
     * @return the y
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * Gets size.
     *
     * @return the size
     */
    public int getSize() {
        return this.r;
    }

    /**
     * Gets v.
     *
     * @return the v
     */
    public Velocity getV() {
        return this.v;
    }

    /**
     * Gets color.
     *
     * @return the color
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * Draw on.
     *
     * @param surface the surface
     */
// draw the ball on the given DrawSurface
    public void drawOn(DrawSurface surface) {
        surface.setColor(getColor());
        surface.fillCircle(getX(), getY(), getSize());
    }


    /**
     * Sets velocity.
     *
     * @param v1 the v
     */
    public void setVelocity(Velocity v1) {
        setVelocity(v1.getDx(), v1.getDy());
    }

    /**
     * Sets velocity.
     *
     * @param dx the dx
     * @param dy the dy
     */
    public void setVelocity(double dx, double dy) {
        this.v = new Velocity(dx, dy);
    }

    /**
     * Gets velocity.
     *
     * @return the velocity
     */
    public Velocity getVelocity() {
        return this.v;
    }

    /**
     * Moving the ball until it gets close enoguh to the wall.
     */
    public void moveOneStep() {
        if (this.v == null) {
            return;
        }
        if (this.v.getDx() > 0) {
            if (this.center.getX() + this.r + this.v.getDx()
                >= this.xHighBorder) {
                this.center = new Point(this.xHighBorder + this.v.getDx()
                    - this.r, this.center.getY());
                setVelocity(-this.v.getDx(), this.v.getDy());
            }
        } else if (this.v.getDx() < 0) {
            if (this.center.getX() - this.r + this.v.getDx()
                <= this.xLowBorder) {
                this.center = new Point(this.xLowBorder + this.v.getDx()
                    + this.r, this.center.getY());
                setVelocity(-this.v.getDx(), this.v.getDy());
            }
        }
        if (this.v.getDy() > 0) {
            if (this.center.getY() + this.r + this.v.getDy()
                >= this.yHighBorder) {
                this.center = new Point(this.center.getX(), this.yHighBorder
                    - this.r + this.v.getDy());
                setVelocity(this.v.getDx(), -this.v.getDy());
            }
        } else if (this.v.getDy() < 0) {
            if (this.center.getY() - this.r + this.v.getDy()
                <= this.yLowBorder) {
                this.center = new Point(this.center.getX(), this.yLowBorder
                    + this.r + this.v.getDy());
                setVelocity(this.v.getDx(), -this.v.getDy());
            }
        }
        this.center = this.getVelocity().applyToPoint(this.center);
    }
}
