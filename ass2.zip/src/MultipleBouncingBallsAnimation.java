import java.util.Random;

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * Eitan Kerzhner
 *
 * The type Multiple bouncing balls animation.
 */
public class MultipleBouncingBallsAnimation {

    /**
     * The Wide.
     */
    static final int WIDE = 200;
    /**
     * The High.
     */
    static final int HIGH = 200;


    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        Random rand = new Random();
        int numberOfBalls = args.length;
        Ball[] ballsArrays = new Ball[numberOfBalls];
        GUI gui = new GUI("title", WIDE, HIGH);
        Sleeper sleeper = new Sleeper();
        for (int i = 0; i < numberOfBalls; i++) {
            // making balls
            int r = Integer.parseInt(args[i]);
            int x = rand.nextInt(200) + 1;
            int y = rand.nextInt(200) + 1;
            ballsArrays[i] = new Ball(x, y, r, java.awt.Color.black);
            ballsArrays[i].setBorders(0, WIDE, 0, HIGH);
            Velocity v = Velocity.fromAngleAndSpeed(rand.nextInt(360) + 1,
                    100 / r); // check if needs to be modified. ****************
            ballsArrays[i].setVelocity(v);
        }
        while (true) {
            // making balls move
            for (int i = 0; i < numberOfBalls; i++) {
                ballsArrays[i].moveOneStep();
            }
            DrawSurface d = gui.getDrawSurface();
            for (int i = 0; i < numberOfBalls; i++) {
                ballsArrays[i].drawOn(d);
            }
            gui.show(d);
            sleeper.sleepFor(50);  // wait for 50 milliseconds.
        }    }
}
