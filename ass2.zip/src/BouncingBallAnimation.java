import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * Eitan Kerzhner
 *
 * The type Bouncing ball animation.
 */
public class BouncingBallAnimation {

    /**
     * The Wide range.
     */
    static final int WIDE = 200;
    /**
     * The High range.
     */
    static final int HIGH = 200;

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        GUI gui = new GUI("title", WIDE, HIGH);
        Sleeper sleeper = new Sleeper();
        Ball ball = new Ball(50, 50, 30, java.awt.Color.black);
        ball.setBorders(0, WIDE, 0, HIGH);
        //    ball.setVelocity(2, 2);
        Velocity v = Velocity.fromAngleAndSpeed(90, 2); // can be changed
        ball.setVelocity(v);
        while (true) {
            ball.moveOneStep();
            DrawSurface d = gui.getDrawSurface();
            ball.drawOn(d);
            gui.show(d);
            sleeper.sleepFor(50);  // wait for 50 milliseconds.
        }
    }
}
