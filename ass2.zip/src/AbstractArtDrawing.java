import biuoop.GUI;
import biuoop.DrawSurface;

import java.util.Random;
import java.awt.Color;

/**
 * Eitan Kerzhner
 *
 * The type Abstract art drawing.
 */
public class AbstractArtDrawing {

    /**
     * Draw random circles.
     */
    public void drawRandomCircles() {
        Random rand = new Random(); // create a random-number generator
        // Create a window with the title "Random Circles Example"
        // which is 400 pixels wide and 300 pixels high.
        GUI gui = new GUI("Random Circles Example", 400, 300);
        DrawSurface d = gui.getDrawSurface();
        for (int i = 0; i < 10; ++i) {
            int x = rand.nextInt(400) + 1; // get integer in range 1-400
            int y = rand.nextInt(300) + 1; // get integer in range 1-300
            int r = 5 * (rand.nextInt(4) + 1); // get integer in 5,10,15,20
            d.setColor(Color.blue);
            d.fillCircle(x, y, r);
        }
        gui.show(d);
    }
    /**
     * Draw random lines.
     */
    public void drawRandomLines() {
        Line[] arrLines = new Line[10];
        Random rand = new Random(); // create a random-number generator
        // Create a window with the title "Random Lines Example"
        // which is 400 pixels wide and 300 pixels high.
        GUI gui = new GUI("Random Lines Example", 400, 300);
        DrawSurface d = gui.getDrawSurface();
        // prints all the lines and marks the center in blue
        for (int i = 0; i < 10; i++) {
            int x1 = rand.nextInt(400) + 1; // get integer in range 1-400
            int y1 = rand.nextInt(300) + 1; // get integer in range 1-300
            int x2 = rand.nextInt(400) + 1; // get integer in range 1-400
            int y2 = rand.nextInt(300) + 1; // get integer in range 1-300
            arrLines[i] = new Line(x1, y1, x2, y2);
            d.setColor(Color.black);
            d.drawLine(x1, y1, x2, y2);
            d.setColor(Color.blue);
            d.fillCircle((int) arrLines[i].middle().getX(), (int) arrLines[i].middle().getY(),
                    5);
        }
        // finds the intersection points of all lines.
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (arrLines[i].isIntersecting(arrLines[j])) {
                    Point inter = arrLines[i].intersectionWith(arrLines[j]);
                    d.setColor(Color.red);
                    d.fillCircle((int) inter.getX(), (int) inter.getY(), 5);
                }
            }
        }
        gui.show(d);
    }

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        AbstractArtDrawing example = new AbstractArtDrawing();
        example.drawRandomLines();
    }
}


