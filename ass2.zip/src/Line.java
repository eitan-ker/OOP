/**
 * Eitan Kerzhner
 *
 * The type Line.
 */
public class Line {
    private Point start;
    private Point end;

    /**
     * Instantiates a new Line.
     *
     * @param start the start
     * @param end   the end
     */
// constructors
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }

    /**
     * Instantiates a new Line.
     *
     * @param x1 the x 1
     * @param y1 the y 1
     * @param x2 the x 2
     * @param y2 the y 2
     */
    public Line(double x1, double y1, double x2, double y2) {
        if (x1 < x2) { //if x1 < x2 means the input was good
            this.start = new Point(x1, y1);
            this.end = new Point(x2, y2);
        } else if (x1 > x2) { //if x2 > x1 means we need to switch
            this.start = new Point(x2, y2);
            this.end = new Point(x1, y1);
        } else { // if x1 = x2
            this.start = new Point(x1, y1);
            this.end = new Point(x2, y2);
        }

    }

    /**
     * Length double.
     *
     * @return the double
     */
// Return the length of the line
    public double length() {
        double dx = this.end.getX() - this.start.getX();
        double dy = this.end.getY() - this.start.getY();
        double sum = 0;
        sum = (dx * dx) + (dy * dy);
        sum = Math.sqrt(sum);
        return sum;
    }

    /**
     * Middle point.
     *
     * @return the point
     */
// Returns the middle point of the line
    public Point middle() {
        double x = ((this.end.getX() - this.start.getX()) / 2) + this.start.getX();
        double y = ((this.end.getY() - this.start.getY()) / 2) + this.start.getY();
        Point middle = new Point(x, y);
        return middle;
    }

    /**
     * Start point.
     *
     * @return the point
     */
// Returns the start point of the line
    public Point start() {
        return this.start;
    }

    /**
     * End point.
     *
     * @return the point
     */
// Returns the end point of the line
    public Point end() {
        return this.end;
    }

    /**
     * Line slope double.
     *
     * @param start1 the start
     * @param end1   the end
     * @return the double
     */
// checks the angle of the line
    public double lineSlope(Point start1, Point end1) {
        double dx = 0;
        double dy = 0;
        dx = end1.getX() - start1.getX();
        dy = end1.getY() - start1.getY();
        return (dy / dx);
    }

    /**
     * Is intersecting boolean.
     *
     * @param other the other
     * @return the boolean
     */
// Returns true if the lines intersect, false otherwise
    public boolean isIntersecting(Line other) {
        // checking if x is sent by corecct order.
        if ((this.start.getX() != this.end.getX())
                && (other.start.getX() != other.end.getX())) {
            double m1 = lineSlope(this.start, this.end);
            double m2 = lineSlope(other.start, other.end);
            double b1 = this.start.getY() - (m1 * this.start.getX());
            double b2 = other.start.getY() - (m2 * other.start.getX());
            if (m1 == m2) {
                return false;
            } else {
                double x = (b2 - b1) / (m1 - m2);
                if (((x >= max(this.start.getX(), other.start.getX()))
                        &&
                        (x <= min(this.end.getX(), other.end.getX())))) {
                    return true;
                }
                return false;
            }

        } else if ((this.start.getX() == this.end.getX())
                && (other.start.getX() == other.end.getX())) {
            return false;
        } else if (this.start.getX() == this.end.getX()) {
            if ((this.start.getX() >= other.start.getX())
                    && (this.start.getX() <= other.end.getX())) {
                return true;
            }
            return false;
        } else if (other.start.getX() == other.end.getX()) {
            if ((other.start.getX() >= this.start.getX())
                    && (other.start.getX() <= this.end.getX())) {
                return true;
            }
            return false;
        } // in case one of the lines is parallel to Y axis.
        return false;
    }

    /**
     * Intersection with lines.
     *
     * @param other the other
     * @return the point
     */
// Returns the intersection point if the lines intersect,
    // and null otherwise.
    public Point intersectionWith(Line other) {
        if ((this.start.getX() != this.end.getX())
                && (other.start.getX() != other.end.getX())) {
            double m1 = lineSlope(this.start, this.end);
            double m2 = lineSlope(other.start, other.end);
            double b1 = this.start.getY() - (m1 * this.start.getX());
            double b2 = other.start.getY() - (m2 * other.start.getX());
            double x = (b2 - b1) / (m1 - m2);
            double y = (m1 * x) + b1;
            if (((x >= max(this.start.getX(), other.start.getX()))
                    &&
                    (x <= min(this.end.getX(), other.end.getX())))) {
                Point interPoint = new Point(x, y);
                return interPoint;
            }
        } else {
            if (this.start.getX() == this.end.getX()) {
                // in case one of the lines is parallel to Y axis.
                double m = lineSlope(other.start, other.end);
                double b = other.start.getY() - (m * other.start.getX());
                double y = (m * this.start.getX()) + b;
                Point interPoint = new Point(this.start.getX(), y);
                return interPoint;
            } else if (other.start.getX() == other.end.getX()) {
                // in case one of the lines is parallel to Y axis.
                double m = lineSlope(this.start, this.end);
                double b = this.start.getY() - (m * this.start.getX());
                double y = (m * other.start.getX()) + b;
                Point interPoint = new Point(other.start.getX(), y);
                return interPoint;
            }
        }
        return null;
    }

    /**
     * Equals boolean.
     *
     * @param other the other
     * @return the boolean
     */
// equals -- return true is the lines are equal, false otherwise
    public boolean equals(Line other) {
        double m1 = lineSlope(this.start, this.end);
        double m2 = lineSlope(other.start, other.end);
        if (m1 == m2) {
            double b1 = this.start.getY() - (m1 * this.start.getX());
            double b2 = other.start.getY() - (m2 * other.start.getX());
            double y1 = (m1 * this.start().getX()) + b1;
            double y2 = (m2 * this.start().getX()) + b2;
            if (y1 == y2) {
                return true;
            }
            return false;
        } else {
            return false;
        }
    }

    /**
     * Min double.
     *
     * @param n1 the n 1
     * @param n2 the n 2
     * @return the double
     */
    public double min(double n1, double n2) {
        if (n1 < n2) {
            return n1;
        } else {
            return n2;
        }
    }

    /**
     * Max double.
     *
     * @param n1 the n 1
     * @param n2 the n 2
     * @return the double
     */
    public double max(double n1, double n2) {
        if (n1 > n2) {
            return n1;
        } else {
            return n2;
        }
    }
}
