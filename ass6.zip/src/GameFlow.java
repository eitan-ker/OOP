/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */
import biuoop.KeyboardSensor;

import java.util.List;

/**
 * The type Game flow.
 */
public class GameFlow {
    private AnimationRunner animationRunner;
    private KeyboardSensor keyboardSensor;
    private SpriteCollection sprites;
    private int numOfLevels;

    /**
     * Instantiates a new Game flow.
     *
     * @param ar               the ar
     * @param ks               the ks
     * @param spriteCollection the sprite collection
     */
//constructors
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, SpriteCollection spriteCollection) {
        this.animationRunner = ar;
        this.keyboardSensor = ks;
        this.sprites = spriteCollection;
    }

    /**
     * Run levels.
     *
     * @param levels the levels
     */
    public void runLevels(List<LevelInformation> levels) {

        Counter score = new Counter(0);
        Counter life = new Counter(7);

        for (LevelInformation levelInfo : levels) {

            GameLevel level = new GameLevel(levelInfo, this.keyboardSensor, this.animationRunner, life, score, sprites);
            sprites.addSprite(levelInfo.getBackground());
            level.initialize();

            while (life.getValue() > 0 && level.getNumBocksLeft() > 0) {
                level.playOneTurn();
            }
            sprites.removeSprite(levelInfo.getBackground());
            if (life.getValue() == 0) {
                this.animationRunner.run(new KeyPressStoppableAnimation(keyboardSensor, KeyboardSensor.SPACE_KEY,
                        new EndScreen(keyboardSensor, false, score.getValue())));
                break;
            }
            this.numOfLevels++;
        }
        if (this.numOfLevels == levels.size()) {
            this.animationRunner.run(new KeyPressStoppableAnimation(keyboardSensor, KeyboardSensor.SPACE_KEY,
                    new EndScreen(keyboardSensor, true, score.getValue())));
        }
    }
}
