/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 */
import biuoop.GUI;

import java.util.ArrayList;
import java.util.List;

/**
 * The type Ass6Game.
 */
public class Ass6Game {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        List<LevelInformation> levels = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
                if (args[i].equals("1")) {
                    levels.add(new DirectHit());
                }
                if (args[i].equals("2")) {
                    levels.add(new WideEasy());
                }
                if (args[i].equals("3")) {
                    levels.add(new Green3());
                }
                if (args[i].equals("4")) {
                    levels.add(new Final4());
                }
            }
        if (levels.isEmpty()) {
            levels.add(new DirectHit());
            levels.add(new WideEasy());
            levels.add(new Green3());
            levels.add(new Final4());
        }
        GUI gui = new GUI("run", 800, 600);
        SpriteCollection sprites = new SpriteCollection();
        AnimationRunner animation = new AnimationRunner(gui);
        biuoop.KeyboardSensor keyboardSensor = gui.getKeyboardSensor();


        GameFlow game = new GameFlow(animation, keyboardSensor, sprites);
        game.runLevels(levels);
        gui.close();
    }
}
