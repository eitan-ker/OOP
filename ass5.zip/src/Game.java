
import java.awt.Color;

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 * <p>
 * The type Game.
 */
public class Game {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Counter remainingBlock;
    private Counter remainingBalls;
    private Counter score;
    private Counter life;
    private Paddle paddle;

    /**
     * Instantiates a new Game.
     */
    public Game() {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.gui = new GUI("run", 800, 800);
    }

    /**
     * Add collidable.
     *
     * @param c the c
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * Add sprite.
     *
     * @param s the s
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * Initialize.
     */
// Initialize a new game: create the Blocks and Ball (and Paddle)
    // and add them to the game.
    public void initialize() {

        this.remainingBlock = new Counter(0);
        this.remainingBalls = new Counter(0);
        this.score = new Counter(0);
        this.life = new Counter(4);
        BlockRemover remover = new BlockRemover(this, this.remainingBlock);
        BallRemover remover2 = new BallRemover(this, this.remainingBalls);
        ScoreTrackingListener countingScore = new ScoreTrackingListener(this.score);

        // date block
        Point data = new Point(0, 0);
        Rectangle dataRec = new Rectangle(data, 800, 20, Color.LIGHT_GRAY);
        Block dataBlock = new Block(dataRec, 0);
        dataBlock.addToGame(this);
        ScoreIndicator index = new ScoreIndicator(this.score, dataBlock);
        index.addToGame(this);
        LivesIndicator lives = new LivesIndicator(this.life, dataBlock);
        lives.addToGame(this);

        // walls initialize
        Point w1 = new Point(0, 20);
        Rectangle rw1 = new Rectangle(w1, 800, 20, Color.yellow);
        Block wall1 = new Block(rw1, 0);
        wall1.addToGame(this);

        Point w2 = new Point(0, 20);
        Rectangle rw2 = new Rectangle(w2, 20, 800, java.awt.Color.red);
        Block wall2 = new Block(rw2, 0);
        wall2.addToGame(this);

        Point w3 = new Point(780, 20);
        Rectangle rw3 = new Rectangle(w3, 20, 800, Color.red);
        Block wall3 = new Block(rw3, 0);
        wall3.addToGame(this);

        // lower wall - death region
        Point w4 = new Point(0, 790);
        Rectangle rw4 = new Rectangle(w4, 800, 20, Color.darkGray);
        Block wall4 = new Block(rw4, 0);
        wall4.addToGame(this);
        wall4.addHitListener(remover2);

        // blocs initialize
        // run on lines
        for (int i = 0; i < 5; i++) {
            // run on columns
            int counter = 1;
            for (int j = 10 - i; j > 0; j--) {
                // setting point
                Point p = new Point(780 - (counter * 50), 100
                        + (25 * i));
                if (i == 0) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            Color.magenta);
                    Block b = new Block(rectangle, 2);
                    b.addToGame(this);
                    b.addHitListener(remover);
                    b.addHitListener(countingScore);
                    this.remainingBlock.increase(1);
                } else if (i == 1) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            Color.yellow);
                    Block b = new Block(rectangle, 1);
                    b.addToGame(this);
                    b.addHitListener(remover);
                    b.addHitListener(countingScore);
                    this.remainingBlock.increase(1);

                } else if (i == 2) {
                    // making a black hole
                    if (j == 4) {
                        Rectangle rectangle = new Rectangle(p, 50, 25,
                                Color.black);
                        Block b = new Block(rectangle, 1);
                        b.addToGame(this);
                        b.addHitListener(remover2);
                        b.addHitListener(countingScore);
                    } else {
                        Rectangle rectangle = new Rectangle(p, 50, 25,
                                Color.blue);
                        Block b = new Block(rectangle, 1);
                        b.addToGame(this);
                        b.addHitListener(remover);
                        b.addHitListener(countingScore);
                        this.remainingBlock.increase(1);
                    }
                } else if (i == 3) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            Color.yellow);
                    Block b = new Block(rectangle, 1);
                    b.addToGame(this);
                    b.addHitListener(remover);
                    b.addHitListener(countingScore);
                    this.remainingBlock.increase(1);
                } else if (i == 4) {
                    Rectangle rectangle = new Rectangle(p, 50, 25,
                            Color.magenta);
                    Block b = new Block(rectangle, 1);
                    b.addToGame(this);
                    b.addHitListener(remover);
                    b.addHitListener(countingScore);
                    this.remainingBlock.increase(1);
                }
                counter++;
            }
        }
    }

    /**
     * Run.
     */
// Run the game -- start the animation loop.
    public void playOneTurn() {
        makeBalls();
        makePaddle();
        Sleeper sleeper = new Sleeper();
        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = gui.getDrawSurface();
            // fill board
            d.setColor(Color.gray);
            d.fillRectangle(0, 0, 800, 800);
            this.sprites.drawAllOn(d);
            gui.show(d);
            if (this.remainingBlock.getValue() == 0) {
                this.score.increase(100);
                gui.close();
                return;
            }
            if (this.remainingBalls.getValue() == 0) {
                this.life.decrease(1);
                if (this.life.getValue() == 0) {
                    gui.close();
                    return;
                }
                this.paddle.removeFromGame(this);
                return;
            }

            this.sprites.notifyAllTimePassed();

            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }

    /**
     * Instantiates a new Remove collidable.
     *
     * @param c the c
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);
    }

    /**
     * Instantiates a new Remove sprite.
     *
     * @param s the s
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSprite(s);
    }

    /**
     * Make balls.
     */
    public void makeBalls() {
        Ball ball1 = new Ball(400, 300, 5, Color.cyan);
        Velocity v1 = Velocity.fromAngleAndSpeed(230, 8);
        ball1.setVelocity(v1);
        ball1.setEnvironment(this.environment);
        ball1.addToGame(this);
        this.remainingBalls.increase(1);

        Ball ball2 = new Ball(380, 300, 5, Color.cyan);
        Velocity v2 = Velocity.fromAngleAndSpeed(230, 8);
        ball2.setVelocity(v2);
        ball2.setEnvironment(this.environment);
        ball2.addToGame(this);
        this.remainingBalls.increase(1);
    }

    /**
     * Make paddle.
     */
    public void makePaddle() {
        biuoop.KeyboardSensor keyboard = gui.getKeyboardSensor();
        Point uperLeftPaddle = new Point(350, 775);
        Rectangle rect = new Rectangle(uperLeftPaddle, 100, 10,
                Color.yellow);
        this.paddle = new Paddle(keyboard, rect);
        paddle.setBorders(20, 780);
        paddle.addToGame(this);
    }

    /**
     * Gets lives.
     *
     * @return the lives
     */
    public int getLives() {
        return this.life.getValue();
    }
}
