
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import biuoop.DrawSurface;

/**
 * Eitan Kerzhner
 * 205697139
 * kerzhne
 * <p>
 * The type Block.
 */
public class Block implements Collidable, Sprite, HitNotifier {
    private List<HitListener> hitListeners = new ArrayList<HitListener>();
    private Rectangle rect;
    private int hp;

    /**
     * Instantiates a new Block.
     *
     * @param rect the rect
     * @param hp   the hp
     */
    public Block(Rectangle rect, int hp) {
        this.rect = rect;
        this.hp = hp;
    }

    /**
     * Sets hp.
     */
    public void setHp() {
        if (this.hp == 0) {
            this.hp = 0;
        } else {
            this.hp = this.hp - 1;
        }
    }

    /**
     * Gets hp.
     *
     * @return the hp
     */
    public int getHp() {
        return this.hp;
    }

    /**
     * Gets color.
     *
     * @return the color
     */
    public java.awt.Color getColor() {
        return this.rect.getColor();
    }

    /**
     * Draw figures.
     *
     * @param d the surface
     */
    public void drawOn(DrawSurface d) {
        // fill rectangle;
        d.setColor(getColor());
        Point point = this.rect.getUpperLeft();
        double width = this.rect.getWidth();
        double height = this.rect.getHeight();
        d.fillRectangle((int) point.getX(), (int) point.getY(), (int) width,
                (int) height);
        d.setColor(Color.black);
        // draw upper line
        d.drawLine((int) this.rect.getUpperLeft().getX(), (int) this.rect.
                getUpperLeft().getY(), (int) (this.rect.getUpperLeft().getX()
                + this.rect.getWidth()), (int) this.rect.getUpperLeft().getY());
        d.drawLine((int) this.rect.getUpperLeft().getX(), (int) this.rect.
                        getUpperLeft().getY(), (int) (this.rect.getUpperLeft().getX()),
                (int) (this.rect.getUpperLeft().getY()
                        + this.rect.getHeight()));
        d.drawLine((int) this.rect.getUpperLeft().getX(), (int) (this.rect.
                        getUpperLeft().getY() + this.rect.getHeight()), (int) (this.
                        rect.getUpperLeft().getX() + this.rect.getWidth()),
                (int) (this.rect.getUpperLeft().getY()
                        + this.rect.getHeight()));
        d.drawLine((int) (this.rect.getUpperLeft().getX()
                + this.rect.getWidth()), (int) (this.rect.getUpperLeft().
                getY()), (int) (this.rect.getUpperLeft().getX() + this.
                rect.getWidth()), (int) (this.rect.
                getUpperLeft().getY() + this.rect.
                getHeight()));
    }

    /**
     * Time passed.
     */
    public void timePassed() {
    }

    /**
     * @return the  rectangle
     */
// Return t
    public Rectangle getCollisionRectangle() {
        return this.rect;
    }

    /**
     * Hit velocity.
     *
     * @param collisionPoint  the collision point
     * @param currentVelocity the current velocity
     * @param hitter          the ball that hitts.
     * @return the velocity after hit
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        int counter = 0;
        double dx = currentVelocity.getDx();
        double x = collisionPoint.getX();
        double dy = currentVelocity.getDy();
        double y = collisionPoint.getY();
        double wide = this.rect.getWidth();
        double height = this.rect.getHeight();
        double upperLeftY = this.rect.getUpperLeft().getY();
        double upperLeftX = this.rect.getUpperLeft().getX();

        if (Math.abs(y - upperLeftY) < 0.01 || Math.abs(y - upperLeftY
                - height) < 0.01) {
            dy = -dy;
            counter++;
        }
        if (Math.abs(x - upperLeftX) < 0.01 || Math.abs(x - upperLeftX
                - wide) < 0.01) {
            dx = -dx;
            counter++;
        }
        if (counter > 0) {
            this.notifyHit(hitter);
            this.setHp();

        }
        Velocity newV = new Velocity(dx, dy);
        return newV;
    }

    /**
     * Add to game.
     *
     * @param g the g
     */
    public void addToGame(Game g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

    /**
     * Remove from game.
     *
     * @param game the game
     */
    public void removeFromGame(Game game) {
        game.removeCollidable(this);
        game.removeSprite(this);
    }

    /**
     * Add hit listener.
     *
     * @param hl the hl
     */
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    /**
     * Remove hit listener.
     *
     * @param hl the hl
     */
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }

    /**
     * notify when a hitt occur.
     *
     * @param hitter the hitting ball
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }
}
