/**
 * the program gets a number to param and prints the factorial
 * using a calculation of a recursion and a iteration for.
 *
 * @author Eitan Kerzhner
 */

public class Factorial {
/**
 * calculating the factorial of number n using iterations.
 *
 * @param n is the number we recieve to calculate its factorial.
 * sum using to calculate the factorial
 * i index using for
 * @return the factorial calculating by iteration.
 */
public static long factorialIter(long n) {
    long sum = 1;
    for (int i = 0; i < n; i++) {
        sum = sum * (n - i);
    }
    return sum;
}

/**
 * calculation the factorial of number n using recursion.
 *
 * @param n is the number we recieve to calculate its factorial.
 * @return the factorial calculation using recursion.
 */
public static long factorialRecursive(long n) {
    if (n == 1) {
        return n;
    }
    return n * factorialRecursive(n - 1);
}

/**
 * getting the number in a string, converts it to int and
 * sending to the methods to calculate the factorial using
 * 2 different ways - a recursion and iteration and prints them.
 *
 * @param args it's the string to get the number int we convert.
 * num1 - geting the factorial calculating by iteration.
 * num2 - geting the factorial calculating by recursion.
 * @see the factorial calculation using the 2 methods.
 */
public static void main(String[] args) {
    long n = Long.parseLong(args[0]);
    long num1 = factorialIter(n);
    long num2 = factorialRecursive(n);
    System.out.println("recursive: " + num2);
    System.out.println("iterative: " + num1);
}
}


