/**
 * the program gets a list of numbers and the output is
 * the maximum, minimum number and the avarge of all
 * numbers.
 *
 * @author Eitan Kerzhner
 */
public class DescribeNumbers {

/**
 * this method gets a string of numbers, it converts
 * those strings into ints and returns the int array.
 *
 * @param numbers gets the string of numbers which
 * later we convert to ints.
 * @return the new arrays of ints instead of strings.
 */
public static int[] stringsToInts(String[] numbers) {
    int[] helpNumbers = new int[numbers.length];
    for (int i = 0; i < numbers.length; i++) {
        helpNumbers[i] = Integer.parseInt(numbers[i]);
    }
    return helpNumbers;
}

/**
 * this method finds the minimum number and returns it.
 *
 * @param numbers is the int array of numbers we find the minimum.
 * @return the minimum number in the array.
 * min is the paramater we use to find the minimum number.
 * i is index.
 */
public static int min(int[] numbers) {
    int min = numbers[0];
    for (int i = 1; i < numbers.length; i++) {
        if (min > numbers[i]) {
            min = numbers[i];
        }
    }
    return min;
}

/**
 * this method finds the maximum number and returns it.
 *
 * @param numbers is the int array of numbers we find the maximum.
 * @return the maximum number in the array.
 * mix is the paramater we use to find the maximum number.
 * i is index.
 */
public static int max(int[] numbers) {
    int max = numbers[0];
    for (int i = 1; i < numbers.length; i++) {
        if (max < numbers[i]) {
            max = numbers[i];
        }
    }
    return max;
}

/**
 * this method sums all the numbers in the array and calculates
 * the avarage.
 *
 * @param numbers is the int array of numbers we find the avarage..
 * @return the avarage number in the array.
 * avg is the paramater we use to find the minimum number.
 * i is index.
 */
public static float avg(int[] numbers) {
    float  avg = 0;
    for (int i = 0; i < numbers.length; i++) {
        avg = avg + numbers[i];
    }
    return (avg / numbers.length);
}

/**
 * calls the 3 methods and than prints all the answers -
 * avarge, minimum number, maximum number.
 *
 * numbers array used to get to converted array of ints.
 * @param args is the string array of the numbers.
 * @see the min/max number and avarge.
 */
public static void main(String[] args) {
    int[] numbers = new int[args.length];
    numbers = stringsToInts(args);
    System.out.println("min: " + min(numbers));
    System.out.println("max: " + max(numbers));
    System.out.println("avg: " + avg(numbers));
}
}
