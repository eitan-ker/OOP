/**
 * the program is sorting an array of numbers. recieves a string
 * of array which first place is a word the means which oreder to sort
 * asc sorting by ascending order, desc is sorting by descnding order.
 * the numbers we need to sort comes after the first string in the array.
 * @version 1.0
 * @author Eitan Kerzhner
 */
public class Sort {

/**
 * return an array of all the numbers contained in numbers array which
 * we get as param.
 *
 * @param numbers gets a array of string which contain the first word
 * and the numbers to sort.
 * helpNumbers is an helping array to get all numbers from
 * numbers array.
 * i index to use for.
 * @return the new array with only numbers inside.
 */
public static int[] stringsToInts(String[] numbers) {
    int[] helpNumbers = new int[numbers.length - 1];
    for (int i = 0; i < helpNumbers.length; i++) {
        helpNumbers[i] = Integer.parseInt(numbers[i + 1]);
    }
    return helpNumbers;
}

/**
 * this method is sorting the array we get by ascending order and
 * prints them using "stringsToInts" method.
 *
 * @param args gets the first array we got as input to work on.
 * numbers array using "stringsToInts" we get to numbers array  all the
 * numbers from the args array.
 * i index to use for.
 * j index to use for.
 * @see sorted array by ascending order.
 */
public static void ascPrint(String[] args) {
    int temp = 0;
    int[] numbers = new int[args.length - 1];
    numbers = stringsToInts(args);
    for (int i = 0; i < numbers.length - 1; i++) {
        for (int j = 0; j < numbers.length - 1; j++) {
            if (numbers[j] > numbers[j + 1]) {
                temp = numbers[j];
                numbers[j] = numbers[j + 1];
                numbers[j + 1] = temp;
            }
        }
    }
    for (int i = 0; i < numbers.length; i++) {
        System.out.print(numbers[i] + " ");
    }
}

/**
 * this method is sorting the array we get by descending order and
 * prints them using "stringsToInts" method.
 *
 * @param args gets the first array we got as input to work on.
 * numbers array using "stringsToInts" we get to numbers array  all the
 * numbers from the args array.
 * i index to use for.
 * j index to use for.
 * @see sorted array by descending order.
 */
public static void descPrint(String[] args) {
    int temp = 0;
    int[] numbers = new int[args.length - 1];
    numbers = stringsToInts(args);
    for (int i = 0; i < numbers.length - 1; i++) {
        for (int j = 0; j < numbers.length - 1; j++) {
            if (numbers[j] < numbers[j + 1]) {
                temp = numbers[j];
                numbers[j] = numbers[j + 1];
                numbers[j + 1] = temp;
            }
        }
    }
    for (int i = 0; i < numbers.length; i++) {
        System.out.print(numbers[i] + " ");
    }
}

/**
 * calling the correct method by check on the first index in args array.
 * prints the numbers by the requested order.
 *
 * @param args gets the first array we got as input to work on.
 * @see sorted array by ascending or descending order.
 */
public static void main(String[] args) {
    if (args[0].equals("asc")) {
        ascPrint(args);
    }
    if (args[0].equals("desc")) {
        descPrint(args);
    }
    System.out.println();
}
}
