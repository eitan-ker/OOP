/**
 * the program prints 5 times the word "Hi".
 *
 * @author Eitan Kerzhner
 */

public class HelloWorld {

/**
 * this program prints 5 times the word "Hi".
 *
 * i - is an index.
 * @param args doesn;t get any input.
 * @see 5 times the word "Hi"
 */
  public static void main(String[] args) {
    for (int i = 0; i < 5; i++) {
       System.out.println("Hi");
    }
  }
}
